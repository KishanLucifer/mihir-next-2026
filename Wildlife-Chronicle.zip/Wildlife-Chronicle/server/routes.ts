import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // === Categories ===
  app.get(api.categories.list.path, async (req, res) => {
    const items = await storage.getCategories();
    res.json(items);
  });

  app.get(api.categories.get.path, async (req, res) => {
    const item = await storage.getCategory(Number(req.params.id));
    if (!item) return res.status(404).json({ message: "Category not found" });
    res.json(item);
  });

  // === Photos ===
  app.get(api.photos.list.path, async (req, res) => {
    const categoryId = req.query.categoryId ? Number(req.query.categoryId) : undefined;
    const featured = req.query.featured === 'true';
    const items = await storage.getPhotos(categoryId, featured);
    res.json(items);
  });

  app.get(api.photos.get.path, async (req, res) => {
    const item = await storage.getPhoto(Number(req.params.id));
    if (!item) return res.status(404).json({ message: "Photo not found" });
    res.json(item);
  });

  // === Videos ===
  app.get(api.videos.list.path, async (req, res) => {
    const categoryId = req.query.categoryId ? Number(req.query.categoryId) : undefined;
    const items = await storage.getVideos(categoryId);
    res.json(items);
  });

  app.get(api.videos.get.path, async (req, res) => {
    const item = await storage.getVideo(Number(req.params.id));
    if (!item) return res.status(404).json({ message: "Video not found" });
    res.json(item);
  });

  // === Profile ===
  app.get(api.profile.get.path, async (req, res) => {
    const item = await storage.getProfile();
    if (!item) return res.status(404).json({ message: "Profile not found" });
    res.json(item);
  });

  // === Contact ===
  app.post(api.contact.submit.path, async (req, res) => {
    try {
      const input = api.contact.submit.input.parse(req.body);
      await storage.createInquiry(input);
      res.status(201).json({ success: true });
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  // Seed Data
  await seedDatabase();

  return httpServer;
}

async function seedDatabase() {
  const existingProfile = await storage.getProfile();
  if (existingProfile) return; // Already seeded

  console.log("Seeding database...");

  // Create Profile
  await storage.createProfile({
    name: "Alex Wilder",
    bio: "Professional wildlife photographer with over 15 years of experience capturing the raw beauty of nature. My work focuses on endangered species and untouched landscapes.",
    avatarUrl: "https://images.unsplash.com/photo-1556103255-4443dbae8e5a",
    coverImageUrl: "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05",
    achievements: [
      { title: "Wildlife Photographer of the Year", year: "2023", description: "Grand Title Winner" },
      { title: "Nat Geo Feature", year: "2022", description: "Cover story on Arctic Foxes" }
    ],
    articles: [
      { title: "Chasing Shadows: The Leopard's Trail", link: "#", publication: "Nature Weekly" },
      { title: "Silence in the Serengeti", link: "#", publication: "Wildlife Mag" }
    ],
    books: [
      { title: "Wild Spirit", link: "#", year: "2020" }
    ],
    socialLinks: [
      { platform: "Instagram", url: "https://instagram.com" },
      { platform: "Twitter", url: "https://twitter.com" }
    ]
  });

  // Create Categories
  const birds = await storage.createCategory({
    name: "Birds",
    slug: "birds",
    description: "Avian species from around the globe.",
    coverImageUrl: "https://images.unsplash.com/photo-1444464666168-49d633b86797",
    type: "photo"
  });

  const animals = await storage.createCategory({
    name: "Wild Animals",
    slug: "wild-animals",
    description: "Mammals in their natural habitat.",
    coverImageUrl: "https://images.unsplash.com/photo-1474511320723-9a56873867b5",
    type: "photo"
  });
  
  const reptiles = await storage.createCategory({
    name: "Reptiles",
    slug: "reptiles",
    description: "Cold-blooded wonders.",
    coverImageUrl: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b",
    type: "photo"
  });

  const videoCat = await storage.createCategory({
    name: "Documentaries",
    slug: "documentaries",
    description: "Short films and behind-the-scenes.",
    coverImageUrl: "https://images.unsplash.com/photo-1516214104703-d43011d62329",
    type: "video"
  });

  // Create Photos
  await storage.createPhoto({
    title: "The Golden Eagle",
    story: "Spotted this magnificent raptor soaring above the Scottish Highlands. I waited for three days in a hide to get this shot.",
    location: "Highlands, Scotland",
    dateTaken: new Date("2023-05-15"),
    url: "https://images.unsplash.com/photo-1508675801627-0642d79691d8",
    categoryId: birds.id,
    isFeatured: true
  });

  await storage.createPhoto({
    title: "Kingfisher Dive",
    story: "A split-second moment where the kingfisher breaks the water surface.",
    location: "River Thames, UK",
    dateTaken: new Date("2023-06-20"),
    url: "https://images.unsplash.com/photo-1522926193341-e9ffd686c60f",
    categoryId: birds.id,
    isFeatured: false
  });

  await storage.createPhoto({
    title: "Lion's Gaze",
    story: "A male lion resting in the afternoon sun.",
    location: "Serengeti, Tanzania",
    dateTaken: new Date("2022-11-10"),
    url: "https://images.unsplash.com/photo-1614027164847-1b28cfe1df60",
    categoryId: animals.id,
    isFeatured: true
  });

  await storage.createPhoto({
    title: "Elephants at Dawn",
    story: "A herd moving through the mist.",
    location: "Amboseli, Kenya",
    dateTaken: new Date("2023-01-05"),
    url: "https://images.unsplash.com/photo-1557050543-4d5f4e07ef46",
    categoryId: animals.id,
    isFeatured: true
  });

  // Create Videos
  await storage.createVideo({
    title: "Life in the Jungle",
    story: "A short film about the biodiversity of the Amazon.",
    url: "https://assets.mixkit.co/videos/preview/mixkit-forest-stream-in-the-sunlight-529-large.mp4",
    previewUrl: "https://images.unsplash.com/photo-1473448912268-2022ce9509d8",
    categoryId: videoCat.id,
    isOffline: false
  });
}
