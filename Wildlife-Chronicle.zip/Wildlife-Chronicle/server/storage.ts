import { db } from "./db";
import {
  categories,
  photos,
  videos,
  profile,
  inquiries,
  type Category,
  type InsertCategory,
  type Photo,
  type InsertPhoto,
  type Video,
  type InsertVideo,
  type Profile,
  type InsertProfile,
  type Inquiry,
  type InsertInquiry
} from "@shared/schema";
import { eq } from "drizzle-orm";

export interface IStorage {
  // Categories
  getCategories(): Promise<Category[]>;
  getCategory(id: number): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;

  // Photos
  getPhotos(categoryId?: number, featured?: boolean): Promise<Photo[]>;
  getPhoto(id: number): Promise<Photo | undefined>;
  createPhoto(photo: InsertPhoto): Promise<Photo>;

  // Videos
  getVideos(categoryId?: number): Promise<Video[]>;
  getVideo(id: number): Promise<Video | undefined>;
  createVideo(video: InsertVideo): Promise<Video>;

  // Profile
  getProfile(): Promise<Profile | undefined>;
  createProfile(profile: InsertProfile): Promise<Profile>;
  
  // Inquiries
  createInquiry(inquiry: InsertInquiry): Promise<Inquiry>;
}

export class DatabaseStorage implements IStorage {
  // Categories
  async getCategories(): Promise<Category[]> {
    return await db.select().from(categories);
  }

  async getCategory(id: number): Promise<Category | undefined> {
    const [category] = await db.select().from(categories).where(eq(categories.id, id));
    return category;
  }

  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const [category] = await db.insert(categories).values(insertCategory).returning();
    return category;
  }

  // Photos
  async getPhotos(categoryId?: number, featured?: boolean): Promise<Photo[]> {
    let query = db.select().from(photos);
    const filters = [];
    
    if (categoryId) filters.push(eq(photos.categoryId, categoryId));
    if (featured) filters.push(eq(photos.isFeatured, true));
    
    if (filters.length > 0) {
      // @ts-ignore - simple and/where logic
      return await query.where(...filters);
    }
    
    return await query;
  }

  async getPhoto(id: number): Promise<Photo | undefined> {
    const [photo] = await db.select().from(photos).where(eq(photos.id, id));
    return photo;
  }

  async createPhoto(insertPhoto: InsertPhoto): Promise<Photo> {
    const [photo] = await db.insert(photos).values(insertPhoto).returning();
    return photo;
  }

  // Videos
  async getVideos(categoryId?: number): Promise<Video[]> {
    if (categoryId) {
      return await db.select().from(videos).where(eq(videos.categoryId, categoryId));
    }
    return await db.select().from(videos);
  }

  async getVideo(id: number): Promise<Video | undefined> {
    const [video] = await db.select().from(videos).where(eq(videos.id, id));
    return video;
  }

  async createVideo(insertVideo: InsertVideo): Promise<Video> {
    const [video] = await db.insert(videos).values(insertVideo).returning();
    return video;
  }

  // Profile
  async getProfile(): Promise<Profile | undefined> {
    // Just return the first profile found as a singleton
    const [item] = await db.select().from(profile).limit(1);
    return item;
  }

  async createProfile(insertProfile: InsertProfile): Promise<Profile> {
    const [item] = await db.insert(profile).values(insertProfile).returning();
    return item;
  }

  // Inquiries
  async createInquiry(insertInquiry: InsertInquiry): Promise<Inquiry> {
    const [inquiry] = await db.insert(inquiries).values(insertInquiry).returning();
    return inquiry;
  }
}

export const storage = new DatabaseStorage();
