import { z } from 'zod';
import { 
  insertInquirySchema, 
  categories, 
  photos, 
  videos, 
  profile 
} from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  categories: {
    list: {
      method: 'GET' as const,
      path: '/api/categories',
      responses: {
        200: z.array(z.custom<typeof categories.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/categories/:id',
      responses: {
        200: z.custom<typeof categories.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    }
  },
  photos: {
    list: {
      method: 'GET' as const,
      path: '/api/photos',
      input: z.object({
        categoryId: z.string().optional(), // Query param is string
        featured: z.string().optional(),
      }).optional(),
      responses: {
        200: z.array(z.custom<typeof photos.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/photos/:id',
      responses: {
        200: z.custom<typeof photos.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    }
  },
  videos: {
    list: {
      method: 'GET' as const,
      path: '/api/videos',
      input: z.object({
        categoryId: z.string().optional(),
      }).optional(),
      responses: {
        200: z.array(z.custom<typeof videos.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/videos/:id',
      responses: {
        200: z.custom<typeof videos.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    }
  },
  profile: {
    get: {
      method: 'GET' as const,
      path: '/api/profile',
      responses: {
        200: z.custom<typeof profile.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    }
  },
  contact: {
    submit: {
      method: 'POST' as const,
      path: '/api/contact',
      input: insertInquirySchema,
      responses: {
        201: z.object({ success: z.boolean() }),
        400: errorSchemas.validation,
      },
    }
  }
};
