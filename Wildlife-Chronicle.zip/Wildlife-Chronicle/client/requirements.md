## Packages
three | 3D library for immersive background effects
@react-three/fiber | React renderer for Three.js
@react-three/drei | Helpers for React Three Fiber
framer-motion | Smooth page transitions and scroll animations
react-intersection-observer | Detect when elements scroll into view
react-player | For handling video playback elegantly
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging Tailwind classes

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["'Playfair Display', serif"],
  sans: ["'DM Sans', sans-serif"],
}
