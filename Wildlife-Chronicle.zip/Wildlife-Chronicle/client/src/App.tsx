import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AnimatePresence } from "framer-motion";

// Components
import { Navigation } from "@/components/Navigation";
import { BackgroundCanvas } from "@/components/BackgroundCanvas";
import { Footer } from "@/components/Footer";

// Pages
import Home from "@/pages/Home";
import Galleries from "@/pages/Galleries";
import GalleryDetail from "@/pages/GalleryDetail";
import PhotoDetail from "@/pages/PhotoDetail";
import Videos from "@/pages/Videos";
import About from "@/pages/About";
import Contact from "@/pages/Contact";
import NotFound from "@/pages/not-found";

// Page Wrapper for smooth transitions could be added here
function Router() {
  const [location] = useLocation();
  
  return (
    <Switch location={location}>
      <Route path="/" component={Home} />
      <Route path="/galleries" component={Galleries} />
      <Route path="/gallery/:id" component={GalleryDetail} />
      <Route path="/photo/:id" component={PhotoDetail} />
      <Route path="/videos" component={Videos} />
      <Route path="/about" component={About} />
      <Route path="/contact" component={Contact} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="relative min-h-screen flex flex-col font-sans text-foreground">
          {/* 3D Background */}
          <BackgroundCanvas />
          
          {/* Navigation */}
          <Navigation />
          
          {/* Main Content Area */}
          <main className="flex-grow z-10">
            <Router />
          </main>
          
          {/* Footer */}
          <Footer />
          
          <Toaster />
        </div>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
